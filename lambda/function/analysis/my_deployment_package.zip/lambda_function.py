import json
from pytube import YouTube
import openai

client = openai.OpenAI()
AI_MODEL = "gpt-3.5-turbo"

def handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda Container!')
    }
